#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

int Newclient(){
  int reponse;
  struct Client client;
  printf("Souhaitez-vous créer un nouveau compte ? :\n1.oui\n2.non\n");
  scanf("%d", &reponse);
  if(reponse==1){
    printf("Création d'un nouveau compte client\n");
    printf("Nom : ");
    fgets(client.nom, sizeof(client.nom), stdin);
    printf("Prenom : ");
    fgets(client.prenom, sizeof(client.prenom), stdin);
    printf("Nom d'utilisateur : ");
    fgets(client.nomutilisateur, sizeof(client.nomutilisateur), stdin);
    printf("Mot de passe : ");
    fgets(client.motdepasse2, sizeof(client.motdepasse2), stdin);

    FILE *fichierClient = fopen("clients.txt", "a");
    if (fichierClient == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 1;

    fprintf(fichierClient, "Nom: %s\nPrenom: %s\nNom d'utilisateur: %s\nMot de passe: %s\n", client.nom, client.prenom, client.nomutilisateur, client.motdepasse2);

      fclose(fichierClient);

        SaveClient();
      Connexion();
    }    
  }
  else{
    Client();
  }
return 0;
};
