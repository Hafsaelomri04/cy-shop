#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

int Connexionreussie(){
  int choixclientco;
    printf("Que voulez-vous faire :\n");
    printf("\n1.Afficher le stock de voitures\n2.Afficher l'historique\n3.Acheter une voiture\n7.Quitter\n");
    scanf("%d",&choixclientco);
		do{
			switch(choixclientco){
				case(1)://if you want to see the history
					Listevoitures();
					Connexionreussie();
					break;
				//case(2):
					//Historique();
          //Connexionreussie();
					//break;
        case(3):
          Achat();
          Connexionreussie();
				case(7):
					Menu();
				default:
					printf("Entrez un des choix possible\n");
					break;
			}
		}while(choixclientco>7 || choixclientco<=0);
  return 0;
}


int Connexion(){
 struct Client client;
    char nomutilisateur2[20];
    char motdepasse3[20];

    printf("Nom d'utilisateur : ");
    fgets(nomutilisateur2, sizeof(nomutilisateur2), stdin);
    printf("Mot de passe : ");
    fgets(motdepasse3, sizeof(motdepasse3), stdin);

    FILE *fichierClient = fopen("clients.txt", "r");
    if (fichierClient == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 1;
    }

    int estConnecte = 0;

    while (fgets(client.nom, sizeof(client.nom), fichierClient)) {
        fgets(client.prenom, sizeof(client.prenom), fichierClient);
        fgets(client.nomutilisateur, sizeof(client.nomutilisateur), fichierClient);
        fgets(client.motdepasse2, sizeof(client.motdepasse2), fichierClient);

        if (strcmp(client.nomutilisateur, nomutilisateur2) == 0 && strcmp(client.motdepasse2, motdepasse3) == 0) {
            printf("Connexion réussie. Bienvenue, %s !\n", client.nom);
            estConnecte = 1;
            Connexionreussie();
            break;
        }
    }

    // Fermeture du fichier client
    fclose(fichierClient);

    if (!estConnecte) {
        printf("Échec de la connexion. Vérifiez vos informations de connexion.\n");
    }

    return 0;
}
