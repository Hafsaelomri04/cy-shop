
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

int Menu(){
	int choixmenu;
	printf("Bienvenue chez le meilleur fournisseur de voiture !\n\n");
	printf("***Menu***\n");
	printf("Etes-vous ?\n");
	printf("1.Gérant \n");
	printf("2.Client\n");
	printf("3.Quitter\n");
	scanf("%d",&choixmenu);
	do{
		switch(choixmenu){
			case(1):
				Gerant();//Manager interface
				break;
			case(2):
				Client();//Client interface
				break;
			case(3):
				break;
			default:
				printf("Entrez un chiffre entre 1 et 3\n");
				scanf("%d",&choixmenu);
				break;
		}
	}while(choixmenu>3 || choixmenu<=0);	
 }
	